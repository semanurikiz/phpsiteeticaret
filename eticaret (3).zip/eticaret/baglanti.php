<?php 
$host='localhost';
$kullanici='root';
$sifre='';
$veritabani='eticaret';
$tablo='ayar';
$baglanti=mysqli_connect($host,$kullanici,$sifre);
?>